# Catalog Consolidation

A command-line tool that takes a seller product file (`ProductEntry.json`) and merges it into a
marketplace catalog stored in SQLite (`catalog.db`). Each entry either links the seller to a
product that already exists, creates a new product, or is held for a human to decide. It never
inserts a duplicate of an existing product. Every entry gets one outcome code, written to a
per-entry JSON Lines report. A whole file runs in a single transaction, so running the same file
again writes nothing.

Deeper documents: [PRD](docs/prds/0001-catalog-consolidation.md) (problem, ambiguities, requirements),
[ADRs](docs/adr/) (decisions), [implementation plan](docs/specs/catalog-consolidation/tasks.md)
(frozen contracts, SQL, acceptance baseline, risks).

## Quick start

Requirements: Python 3.12 and [`uv`](https://docs.astral.sh/uv/). At runtime the tool uses only
the standard library. The dev extra adds `ruff`, `pyright` and `pytest`, pinned to exact versions.

```bash
uv sync --python 3.12 --extra dev
```

`data/` holds the original input and is never written to. Always run against a copy:

```bash
rm -rf out && mkdir -p out && cp data/catalog.db out/catalog.db

.venv/bin/python -m catalog_consolidation migrate --db out/catalog.db
.venv/bin/python -m catalog_consolidation consolidate --db out/catalog.db \
  --input data/ProductEntry.json --report out/report.jsonl
```

`migrate` output (the backup timestamp is the UTC time of the run, `YYYYMMDDTHHMMSSZ`):

```
backup: out/catalog.db.pre-migrate-<timestamp>.bak
applied 0001 seller_product_text_id
applied 0002 product_match_keys (backfilled 975 products)
applied 0003 review_queue
schema version: 3
```

`consolidate` output on the provided data, first run (`<run_id>` is a fresh UUID hex each run):

```
run <run_id> input=data/ProductEntry.json dry_run=false committed=true rows_written=258
LINKED_EXACT                 200
LINKED_NORMALIZED             54
CREATED                        1
UNCHANGED                      1
SKIPPED_DUPLICATE_LISTING     11
HELD_FOR_REVIEW                2
REJECTED_INVALID               0
CONFLICT_SELLER_SKU            0
TOTAL                        269
```

Running the same command again prints `rows_written=0` with `UNCHANGED 256`,
`SKIPPED_DUPLICATE_LISTING 11`, `HELD_FOR_REVIEW 2`, every other code `0`, and `TOTAL 269`.

Stdout carries the summary only. Stderr gets one structured JSON log line per run (`timestamp`, `level`,
`service`, `event` such as `consolidate.finished`, `correlationId` equal to the run id,
`durationMs`, and the run counts). On failure, stderr also gets an `error: <message>` line.

## Commands

```
python -m catalog_consolidation migrate     --db PATH
python -m catalog_consolidation consolidate --db PATH --input PATH [--report PATH] [--dry-run]
python -m catalog_consolidation review list    --db PATH [--status PENDING|LINKED|CREATED|REJECTED] [--limit N] [--after-id ID]
python -m catalog_consolidation review resolve --db PATH --id N (--create | --reject | --link PRODUCT_ID)
```

- `migrate` applies pending migrations from `migrations/`. Before applying anything it copies
  the database to `<db>.pre-migrate-<timestamp>.bak`. When nothing is pending it prints
  `schema version: 3 (up to date)` and takes no backup.
- `consolidate` refuses to run on a missing file or on a database below schema version 3. In
  both cases it exits 2 and, for the schema case, prints the `migrate` command to run.
  `--dry-run` makes every decision and then rolls back (`committed=false`). `--report` writes
  one JSON object per entry, in input order, through a temporary file and an atomic rename, e.g.
  `{"index":180,"sellerName":"MegaStore","sellerProductId":"09835342345-4678-9abc-def012345678","outcome":"CREATED","productId":976,"reviewReason":null,"score":0.4762,"warnings":["non_uuid_seller_sku"],"errors":[]}`.
- `review list` prints a header line and then queue rows as tab-separated columns
  `Id SellerName SellerProductId Reason Score CandidateProductId SourceName`. Defaults:
  `--status PENDING`, `--limit 20` (maximum 100). Paging is by keyset: the last line reads
  `next: --after-id <id>` when more rows exist.
- `review resolve` acts only on a `PENDING` row, in one transaction:
  - `--create` creates the product from the seller's values and links it (`MatchType='CREATED'`).
  - `--link PRODUCT_ID` links the seller to an existing product (`MatchType='REVIEWED'`).
  - `--reject` marks the row `REJECTED`.

  A missing review row, a missing product, a row that is not `PENDING`, a seller already linked
  to that product, or a seller SKU already linked elsewhere prints `error: <code>: ...`, writes
  nothing, and exits 2. After `--link` or `--create`, re-running `consolidate` reports that entry
  as `UNCHANGED`; after `--reject` it reports `HELD_FOR_REVIEW` with the warning
  `review_previously_rejected`.

  On the provided data, `review list` after the first run prints:

  ```
  Id  SellerName   SellerProductId                       Reason  Score   CandidateProductId  SourceName
  1   FootwearHub  a7a7a7a7-b8b8-4c9c-d0d0-e1e1e1e1e1e1  FUZZY   0.9091  21                  Roteador WiFi 6 TP-Link
  2   SuperMart    b4b4b4b4-c5c5-4d6d-e7e7-f8f8f8f8f8f8  FUZZY   0.9643  28                  Processador AMD Ryzen 9 7950X
  ```
  (columns aligned here for reading; the real output is tab-separated)

| Exit code | When |
|---|---|
| 0 | The run finished: committed, rolled back by `--dry-run`, or with rejected, conflicting or held entries; `migrate` finished |
| 2 | Invalid input file (not UTF-8, not JSON, not an array, over 10 MB or 100,000 entries, unreadable); database file missing; schema not migrated; usage error |
| 1 | Anything else (migration error, SQLite error, unexpected exception); the transaction is rolled back |

For example, `printf '{}' > out/bad.json` followed by `consolidate --input out/bad.json` prints
`error: invalid input file: not_an_array: out/bad.json: top-level value is not a JSON array` and
exits 2. Error messages are built from error codes and paths only. They never include
seller-supplied text or a traceback.

## How matching works

For each entry, in file order:

1. **Validate the record.** `Id` must match `[A-Za-z0-9._-]+` and be at most 64 characters.
   `SellerName` and `Name` are required. `Brand` and `Category` are optional. Length limits
   come from `domain/limits.py`. A record that fails is `REJECTED_INVALID` and the rest of the
   file continues. A non-UUID `Id` is accepted with the warning `non_uuid_seller_sku`.
2. **Compute the match key** with `normalize()` (`domain/normalization.py`). Steps run in this
   order:
   - Unicode NFKD, then drop combining marks: `Câmera` becomes `Camera`.
   - Casefold: `BLACK+DECKER` becomes `black+decker`, and `ß` becomes `ss`.
   - Delete quotes (`"`, `'` and their curly forms): `Levi's` becomes `levis`, `55"` becomes `55`.
   - Replace every run of non-`[0-9a-z]` characters with one space, then collapse and trim:
     `Black+Decker` becomes `black decker`, `TP-Link` becomes `tp link`, and doubled spaces
     disappear.
3. **Check whether this seller SKU was seen before**, keyed by `(SellerName, Id)`.
   - Already linked by a human (`MatchType='REVIEWED'`, from `review resolve --link`):
     `UNCHANGED`. A human decision is never re-litigated by the automatic matcher.
   - Already linked automatically: re-match the entry. If it resolves to the same product, the
     outcome is `UNCHANGED`; otherwise it is `CONFLICT_SELLER_SKU` and nothing changes.
   - Already in the review queue: `HELD_FOR_REVIEW`, and no new row is written.
4. **Look for identity matches.** Identity is the normalized name plus a compatible brand.
   Brands are compatible when their normalized forms are equal or either side is NULL
   ("unknown is not different"). Category is not part of identity: sellers use their own
   taxonomies (`Photo` vs `Photography`).
   - One candidate: link. The outcome is `LINKED_EXACT` when the catalog `Name` is byte-equal to
     the seller's raw name, and `LINKED_NORMALIZED` otherwise. If this seller is already linked to
     that product under another SKU, the outcome is `SKIPPED_DUPLICATE_LISTING`.
   - More than one candidate: `HELD_FOR_REVIEW`, reason `AMBIGUOUS`.
5. **No identity match:** score the entry with `difflib.SequenceMatcher.ratio()` against every
   product with a compatible brand. Ties go to the lowest product id.
   - Best score of 0.80 or higher: `HELD_FOR_REVIEW`, reason `FUZZY`, with the candidate and
     score. **A fuzzy score never links on its own.** The threshold only decides between "queue"
     and "create".
   - Otherwise: `CREATED`. The new product takes the seller's values with whitespace collapsed,
     and the seller is linked to it.

The catalog row is the golden record: linking never overwrites `Product.Name`, `Brand` or
`Category`. Each seller's raw values are kept on the link row (`SourceName`, `SourceBrand`,
`SourceCategory`). Every SQL statement is parameterized.

Before matching, every run also fills in missing match keys for any `Product` row whose
`NormalizedName` is NULL, for example rows inserted by another tool.

## Outcome vocabulary

| Code | Meaning | Writes |
|---|---|---|
| `LINKED_EXACT` | Linked to a product whose name is byte-equal to the seller's | 1 link |
| `LINKED_NORMALIZED` | Linked to a product that is equal only after normalization | 1 link |
| `CREATED` | No match and no close candidate; created a product and linked it | 1 product + 1 link |
| `UNCHANGED` | This seller SKU is already linked to the product it resolves to | nothing |
| `SKIPPED_DUPLICATE_LISTING` | This seller already offers that product under a different SKU | nothing |
| `HELD_FOR_REVIEW` | Fuzzy or ambiguous candidate, queued in `ProductMatchReview` (or already queued) | 1 review row, first time only |
| `REJECTED_INVALID` | The record failed validation; `errors` holds `code:Field` pairs | nothing |
| `CONFLICT_SELLER_SKU` | This seller SKU is already linked to a different product | nothing |

## Results on the provided data (2026-10-05)

- 269 entries, 258 rows written. After the run: `SellerProduct` 255 rows, `Product` 976 rows
  (975 + 1), `ProductMatchReview` 2 rows.
- Held for review: `Roteador WiFi 6 TP-Link` (score about 0.91 against `Router WiFi 6 TP-Link`) and
  `Processador AMD Ryzen 9 7950X` (about 0.96 against `Processor AMD Ryzen 9 7950X`). These are
  translations. A 0.96 ratio also separates `7950X` from `7950X3D`, which are different
  products, so no auto-link threshold is safe.
- Created: `Security Test Product`, whose brand `TestBrand'; SELECT 1; --` is stored verbatim as
  data.
- 11 seller duplicates were skipped. Three entries carry non-UUID ids and were accepted with a
  warning.

## Schema changes

The migrations in `migrations/` are additive and forward-only. `SchemaVersion` records each
applied migration with a SHA-256 checksum. Editing an applied migration file fails `migrate`
(`checksum_mismatch`). Each migration commits on its own.

| Migration | Change |
|---|---|
| `0001_seller_product_text_id` | Rebuilds `SellerProduct`: `SellerProductId` becomes `TEXT`. Adds `SourceName`, `SourceBrand`, `SourceCategory`, `MatchType` (`EXACT`, `NORMALIZED`, `CREATED`, `REVIEWED`) and `CreatedAt`. Adds `UNIQUE (SellerName, SellerProductId)` and `UNIQUE (SellerName, ProductId)`. If the row count changes during the copy (orphan links), the migration rolls back with `rows_lost`. |
| `0002_product_match_keys` | Adds `Product.NormalizedName` and `NormalizedBrand` (indexed, not unique) and backfills them with the Python normalizer. |
| `0003_review_queue` | Creates `ProductMatchReview` (candidate, score, reason `FUZZY`/`AMBIGUOUS`, status `PENDING`/`LINKED`/`CREATED`/`REJECTED`), unique per seller SKU. |

There are no down migrations. Recovery is the `.bak` file that `migrate` writes first.

## Key decisions

| Decision | Record |
|---|---|
| Python 3.12 standard-library CLI over SQLite, no runtime dependencies | [ADR 0001](docs/adr/0001-python-stdlib-cli.md) |
| Identity is the normalized name plus a compatible brand; category is not identity; NULL brand is compatible with any brand | [ADR 0002](docs/adr/0002-product-identity-normalized-name-and-brand.md) |
| Seller SKU is opaque `TEXT`, unique per seller; seller values live on the link row; the catalog row is never overwritten | [ADR 0003](docs/adr/0003-seller-link-schema-and-golden-record.md) |
| Uncertain matches (fuzzy, ambiguous) go to a review queue and are never linked or created automatically | [ADR 0004](docs/adr/0004-review-queue-for-uncertain-matches.md) |
| One transaction per file, validation per record, re-runs are no-ops | [ADR 0005](docs/adr/0005-all-or-nothing-idempotent-runs.md) |

All fifteen ambiguities found in the brief and the data, with the evidence and the options
rejected, are listed in [PRD section 4](docs/prds/0001-catalog-consolidation.md#4-ambiguities-and-how-we-resolved-them).

## Project layout

```
src/catalog_consolidation/
  cli.py                  composition root: arguments, wiring, exit codes, JSON log line
  domain/                 stdlib only: models, limits, errors, ports, normalization, matching
  use_cases/              consolidate_file.py (one run = one transaction)
  adapters/               JSON reader, SQLite connection/repository/migrations, report writer
migrations/               0001-0003 SQL files, applied by `migrate`
data/                     original input, never written to
docs/                     PRD, ADRs, implementation plan
```

## Known limitations and next steps

- **No automated tests.** Under this project's process, tests are written only when asked for,
  and none were. Behaviour was checked by running the end-to-end demo above on the provided
  data. A test suite is the first next step.
- **Fuzzy scan is O(catalog) per unmatched entry.** Three entries reach it here. At millions of
  products, it needs a blocking index (token or trigram table).
- **Translations and synonyms are not matched.** `Roteador` and `Processador` reach the review
  queue rather than linking. Matching them automatically needs a dictionary, which is out of scope.
- **Category cannot break a tie.** Two catalog products with the same normalized name and brand
  but different categories would send every matching entry to review as `AMBIGUOUS`. None exist
  in the provided catalog.
- **Seller is a string** (`SellerName`), not an entity. The file has no seller attributes to
  hold.
- **The report is written after the commit.** If writing `--report` fails, the run exits 1 with
  the database already committed. A re-run is safe but reports `UNCHANGED`/`SKIPPED`/`HELD`
  instead of the original outcomes. When the first-run report matters, run with
  `--dry-run --report` first.
- **Migrations require the editable install.** `migrations/` is found through the source tree,
  which `uv sync` provides. A wheel install would not find it.
- **Out of scope:** a review UI, price/stock/offers, ML or embedding matching, an HTTP API, and
  concurrent runs. SQLite's write lock and a 5 s `busy_timeout` serialize concurrent runs; a
  run that loses the race exits 1 and rolls back.
