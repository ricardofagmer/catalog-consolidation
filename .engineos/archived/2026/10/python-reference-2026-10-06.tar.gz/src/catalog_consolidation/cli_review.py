"""`review list` / `review resolve`: wires the review adapters and maps their errors to exit codes.

Registered and dispatched by `cli.py`, which injects its structured log function so both modules
emit the same JSON log schema without importing each other.
"""

import argparse
import logging
import sqlite3
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import Final, Literal, TypeGuard, get_args

from catalog_consolidation.adapters.sqlite_connection import (
    open_connection,
    require_schema_version,
)
from catalog_consolidation.adapters.sqlite_review_repository import SqliteReviewUnitOfWork
from catalog_consolidation.domain.errors import DatabaseFileError
from catalog_consolidation.domain.limits import REPORT_SCORE_DECIMALS
from catalog_consolidation.domain.models import ReviewStatus
from catalog_consolidation.domain.normalization import clean_display
from catalog_consolidation.domain.ports import ReviewRecord
from catalog_consolidation.use_cases.resolve_review import (
    REVIEW_PAGE_DEFAULT_LIMIT,
    REVIEW_PAGE_MAX_LIMIT,
    CreateProduct,
    LinkToProduct,
    ListReviews,
    RejectReview,
    ResolutionResult,
    ResolveCommand,
    ResolveReview,
    ReviewPage,
    ReviewResolutionError,
)

LogFunction = Callable[[int, str, dict[str, object]], None]
ReviewAction = Literal["list", "resolve"]

# Same table as cli.py (frozen decision H); restated because cli.py imports this module.
_EXIT_OK: Final = 0
_EXIT_FAILURE: Final = 1
_EXIT_INVALID_INPUT: Final = 2

_DEFAULT_STATUS: Final[ReviewStatus] = "PENDING"
_REVIEW_STATUSES: Final[tuple[str, ...]] = get_args(ReviewStatus)
_LIST_HEADER: Final = (
    "Id",
    "SellerName",
    "SellerProductId",
    "Reason",
    "Score",
    "CandidateProductId",
    "SourceName",
)
_COLUMN_SEPARATOR: Final = "\t"


def configure_parser(parser: argparse.ArgumentParser) -> None:
    actions = parser.add_subparsers(dest="review_action", required=True, metavar="ACTION")

    list_parser = actions.add_parser("list", help="list review queue rows, oldest first")
    list_parser.add_argument("--db", required=True, type=Path, help="path to the SQLite catalog")
    list_parser.add_argument(
        "--status",
        choices=_REVIEW_STATUSES,
        default=_DEFAULT_STATUS,
        help=f"queue status to list (default {_DEFAULT_STATUS})",
    )
    list_parser.add_argument(
        "--limit",
        type=_page_limit,
        default=REVIEW_PAGE_DEFAULT_LIMIT,
        help=f"rows per page, 1..{REVIEW_PAGE_MAX_LIMIT} (default {REVIEW_PAGE_DEFAULT_LIMIT})",
    )
    list_parser.add_argument(
        "--after-id",
        type=_non_negative_int,
        default=0,
        help="return rows with an Id greater than this (from the previous page's next: line)",
    )

    resolve_parser = actions.add_parser("resolve", help="resolve one PENDING review row")
    resolve_parser.add_argument("--db", required=True, type=Path, help="path to the SQLite catalog")
    resolve_parser.add_argument("--id", required=True, type=_positive_int, help="review row Id")
    decision = resolve_parser.add_mutually_exclusive_group(required=True)
    decision.add_argument(
        "--create",
        action="store_true",
        help="create a new catalog product from the seller's values and link it",
    )
    decision.add_argument(
        "--reject",
        action="store_true",
        help="reject the row; later re-sends stay held for review",
    )
    decision.add_argument(
        "--link",
        type=_positive_int,
        default=None,
        metavar="PRODUCT_ID",
        help="link the seller SKU to this existing catalog product",
    )


def main(*, arguments: argparse.Namespace, correlation_id: str, log: LogFunction) -> int:
    action: object = arguments.review_action
    if not _is_review_action(action):
        raise ValueError(f"unknown review action: {action!r}")
    event = f"review.{action}"
    started = time.monotonic()
    try:
        fields = _list(arguments) if action == "list" else _resolve(arguments)
    except (ReviewResolutionError, DatabaseFileError) as error:
        _fail(log=log, event=event, correlation_id=correlation_id, started=started, error=error)
        return _EXIT_INVALID_INPUT
    except sqlite3.Error as error:
        # sqlite messages can echo values; keep them in neither stderr nor the log.
        _fail(
            log=log,
            event=event,
            correlation_id=correlation_id,
            started=started,
            error=error,
            message=f"database failure (correlationId={correlation_id})",
        )
        return _EXIT_FAILURE
    except Exception as error:
        _fail(
            log=log,
            event=event,
            correlation_id=correlation_id,
            started=started,
            error=error,
            message=f"unexpected failure (correlationId={correlation_id})",
        )
        return _EXIT_FAILURE
    log(
        logging.INFO,
        f"{event}.finished",
        {"correlationId": correlation_id, "durationMs": _elapsed_ms(started), **fields},
    )
    return _EXIT_OK


def _list(arguments: argparse.Namespace) -> dict[str, object]:
    db_path: Path = arguments.db
    status: ReviewStatus = arguments.status
    limit: int = arguments.limit
    after_id: int = arguments.after_id

    connection = open_connection(db_path)
    try:
        require_schema_version(connection)
        use_case = ListReviews(unit_of_work=SqliteReviewUnitOfWork(connection=connection))
        page = use_case.execute(status=status, after_id=after_id, limit=limit)
    finally:
        connection.close()

    _print_page(page)
    return {"status": status, "rows": len(page.records), "hasMore": page.next_after_id is not None}


def _resolve(arguments: argparse.Namespace) -> dict[str, object]:
    db_path: Path = arguments.db
    command = _resolve_command(arguments)

    connection = open_connection(db_path)
    try:
        require_schema_version(connection)
        use_case = ResolveReview(unit_of_work=SqliteReviewUnitOfWork(connection=connection))
        result = use_case.execute(command)
    finally:
        connection.close()

    _print_resolution(result)
    return {
        "reviewId": result.review_id,
        "status": result.status,
        "productId": result.product_id,
        "linkId": result.link_id,
    }


def _resolve_command(arguments: argparse.Namespace) -> ResolveCommand:
    review_id: int = arguments.id
    link_product_id: int | None = arguments.link
    if link_product_id is not None:
        return LinkToProduct(review_id=review_id, product_id=link_product_id)
    if arguments.create:
        return CreateProduct(review_id=review_id)
    return RejectReview(review_id=review_id)


def _print_page(page: ReviewPage) -> None:
    print(_COLUMN_SEPARATOR.join(_LIST_HEADER))
    for record in page.records:
        print(_COLUMN_SEPARATOR.join(_list_columns(record)))
    if page.next_after_id is not None:
        print(f"next: --after-id {page.next_after_id}")


def _list_columns(record: ReviewRecord) -> tuple[str, ...]:
    item = record.item
    score = "" if item.score is None else f"{item.score:.{REPORT_SCORE_DECIMALS}f}"
    candidate = "" if item.candidate_product_id is None else str(item.candidate_product_id)
    return (
        str(item.id),
        _single_line(item.seller_name),
        item.seller_product_id,
        item.reason,
        score,
        candidate,
        _single_line(record.source_name),
    )


def _single_line(text: str) -> str:
    # Seller text may hold tabs or newlines; collapsing them keeps one row per line.
    return clean_display(text) or ""


def _print_resolution(result: ResolutionResult) -> None:
    line = f"review {result.review_id} -> {result.status}"
    if result.product_id is not None:
        line += f" product={result.product_id} link={result.link_id}"
    print(line)


def _fail(
    *,
    log: LogFunction,
    event: str,
    correlation_id: str,
    started: float,
    error: Exception,
    message: str | None = None,
) -> None:
    # Typed errors carry ids, statuses and paths only; seller text never reaches the message.
    print(f"error: {message if message is not None else error}", file=sys.stderr)
    log(
        logging.ERROR,
        f"{event}.failed",
        {
            "correlationId": correlation_id,
            "errorType": type(error).__name__,
            "durationMs": _elapsed_ms(started),
        },
    )


def _elapsed_ms(started: float) -> int:
    return round((time.monotonic() - started) * 1000)


def _is_review_action(value: object) -> TypeGuard[ReviewAction]:
    return isinstance(value, str) and value in get_args(ReviewAction)


def _parse_int(text: str) -> int:
    try:
        return int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"not an integer: {text!r}") from None


def _positive_int(text: str) -> int:
    value = _parse_int(text)
    if value < 1:
        raise argparse.ArgumentTypeError(f"must be >= 1, got {value}")
    return value


def _non_negative_int(text: str) -> int:
    value = _parse_int(text)
    if value < 0:
        raise argparse.ArgumentTypeError(f"must be >= 0, got {value}")
    return value


def _page_limit(text: str) -> int:
    value = _parse_int(text)
    if not 1 <= value <= REVIEW_PAGE_MAX_LIMIT:
        raise argparse.ArgumentTypeError(f"must be between 1 and {REVIEW_PAGE_MAX_LIMIT}")
    return value
