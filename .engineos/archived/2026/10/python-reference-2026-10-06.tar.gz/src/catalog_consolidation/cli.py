"""Composition root: parses arguments, wires adapters, maps errors to exit codes."""

import argparse
import json
import logging
import sqlite3
import sys
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Final, Literal
from uuid import uuid4

from catalog_consolidation import cli_review
from catalog_consolidation.adapters.json_entry_reader import JsonEntryReader
from catalog_consolidation.adapters.report_writer import format_summary, write_jsonl_report
from catalog_consolidation.adapters.sqlite_catalog_repository import SqliteUnitOfWork
from catalog_consolidation.adapters.sqlite_connection import (
    open_connection,
    require_schema_version,
)
from catalog_consolidation.adapters.sqlite_migrations import (
    MigrationReport,
    SqliteMigrationRunner,
    default_migrations_dir,
)
from catalog_consolidation.domain.errors import (
    DatabaseFileError,
    InvalidInputFileError,
    MigrationError,
)
from catalog_consolidation.domain.models import RunSummary
from catalog_consolidation.use_cases.consolidate_file import ConsolidateFile

EXIT_OK: Final = 0
EXIT_FAILURE: Final = 1
EXIT_INVALID_INPUT: Final = 2

_PROGRAM_NAME: Final = "python -m catalog_consolidation"
_SERVICE_NAME: Final = "catalog_consolidation"
_LOGGER_NAME: Final = "catalog_consolidation.cli"
_LOG_FIELDS_ATTRIBUTE: Final = "fields"
_MATCH_KEYS_MIGRATION_VERSION: Final = 2

Command = Literal["migrate", "consolidate"]

_logger = logging.getLogger(_LOGGER_NAME)


@dataclass(frozen=True)
class _LogFields:
    values: Mapping[str, object]


class _JsonLogFormatter(logging.Formatter):
    """One JSON object per line; the record message is the event name."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, object] = {
            "timestamp": datetime.fromtimestamp(record.created, UTC).isoformat(),
            "level": record.levelname.lower(),
            "service": _SERVICE_NAME,
            "event": record.getMessage(),
        }
        fields = record.__dict__.get(_LOG_FIELDS_ATTRIBUTE)
        if isinstance(fields, _LogFields):
            payload.update(fields.values)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _configure_logging() -> None:
    # main() can run more than once in one process (tests, embedding); attach the handler once.
    if _logger.handlers:
        return
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(_JsonLogFormatter())
    _logger.addHandler(handler)
    _logger.setLevel(logging.INFO)
    _logger.propagate = False


def _log(level: int, event: str, fields: dict[str, object]) -> None:
    _logger.log(level, event, extra={_LOG_FIELDS_ATTRIBUTE: _LogFields(values=fields)})


def _elapsed_ms(started: float) -> int:
    return round((time.monotonic() - started) * 1000)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog=_PROGRAM_NAME,
        description="Consolidate seller product files into the marketplace catalog.",
    )
    commands = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")

    migrate = commands.add_parser("migrate", help="apply pending schema migrations")
    migrate.add_argument("--db", required=True, type=Path, help="path to the SQLite catalog")

    consolidate = commands.add_parser("consolidate", help="consolidate a seller product file")
    consolidate.add_argument("--db", required=True, type=Path, help="path to the SQLite catalog")
    consolidate.add_argument(
        "--input", required=True, type=Path, help="seller JSON file (array of entries)"
    )
    consolidate.add_argument(
        "--report", type=Path, default=None, help="write one JSON line per entry to this path"
    )
    consolidate.add_argument(
        "--dry-run",
        action="store_true",
        help="run every decision, then roll back instead of committing",
    )

    review = commands.add_parser("review", help="list or resolve held review queue rows")
    cli_review.configure_parser(review)
    return parser


def _migrate(*, db_path: Path) -> MigrationReport:
    connection = open_connection(db_path)
    try:
        runner = SqliteMigrationRunner(
            connection=connection, db_path=db_path, migrations_dir=default_migrations_dir()
        )
        return runner.apply_pending()
    finally:
        connection.close()


def _print_migration_report(report: MigrationReport) -> None:
    if report.backup_path is not None:
        print(f"backup: {report.backup_path}")
    for migration in report.applied:
        line = f"applied {migration.version:04d} {migration.name}"
        if (
            migration.version == _MATCH_KEYS_MIGRATION_VERSION
            and migration.backfilled_rows is not None
        ):
            line += f" (backfilled {migration.backfilled_rows} products)"
        print(line)
    suffix = "" if report.applied else " (up to date)"
    print(f"schema version: {report.schema_version}{suffix}")


def _consolidate(*, arguments: argparse.Namespace, run_id: str) -> RunSummary:
    db_path: Path = arguments.db
    input_path: Path = arguments.input
    report_path: Path | None = arguments.report
    dry_run: bool = arguments.dry_run

    connection = open_connection(db_path)
    try:
        require_schema_version(connection)
        use_case = ConsolidateFile(
            unit_of_work=SqliteUnitOfWork(connection=connection),
            entry_source=JsonEntryReader(path=input_path),
            input_label=str(input_path),
            run_id=run_id,
        )
        result = use_case.execute(dry_run=dry_run)
    finally:
        connection.close()

    if report_path is not None:
        write_jsonl_report(path=report_path, outcomes=result.outcomes)
    print(format_summary(result.summary))
    return result.summary


def _summary_fields(summary: RunSummary) -> dict[str, object]:
    return {
        "dryRun": summary.dry_run,
        "committed": summary.committed,
        "rowsWritten": summary.rows_written,
        "total": summary.total,
        "counts": dict(summary.counts),
    }


def _fail(
    *,
    command: Command,
    correlation_id: str,
    started: float,
    error: Exception,
    message: str,
) -> None:
    # The message is built from typed error codes and paths only; seller text never reaches it.
    print(f"error: {message}", file=sys.stderr)
    _log(
        logging.ERROR,
        f"{command}.failed",
        {
            "correlationId": correlation_id,
            "errorType": type(error).__name__,
            "durationMs": _elapsed_ms(started),
        },
    )


def _run(*, command: Command, correlation_id: str, action: Callable[[], dict[str, object]]) -> int:
    started = time.monotonic()
    try:
        fields = action()
    except InvalidInputFileError as error:
        _fail(
            command=command,
            correlation_id=correlation_id,
            started=started,
            error=error,
            message=f"invalid input file: {error}",
        )
        return EXIT_INVALID_INPUT
    except DatabaseFileError as error:
        _fail(
            command=command,
            correlation_id=correlation_id,
            started=started,
            error=error,
            message=f"database: {error}",
        )
        return EXIT_INVALID_INPUT
    except MigrationError as error:
        _fail(
            command=command,
            correlation_id=correlation_id,
            started=started,
            error=error,
            message=f"migration failed: {error}",
        )
        return EXIT_FAILURE
    except sqlite3.Error as error:
        # sqlite messages can echo values; keep them in neither stderr nor the log.
        _fail(
            command=command,
            correlation_id=correlation_id,
            started=started,
            error=error,
            message=f"database failure (correlationId={correlation_id})",
        )
        return EXIT_FAILURE
    except Exception as error:
        _fail(
            command=command,
            correlation_id=correlation_id,
            started=started,
            error=error,
            message=f"unexpected failure (correlationId={correlation_id})",
        )
        return EXIT_FAILURE
    _log(
        logging.INFO,
        f"{command}.finished",
        {"correlationId": correlation_id, "durationMs": _elapsed_ms(started), **fields},
    )
    return EXIT_OK


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _build_parser().parse_args(argv)
    _configure_logging()
    correlation_id = uuid4().hex

    if arguments.command == "review":
        return cli_review.main(arguments=arguments, correlation_id=correlation_id, log=_log)

    if arguments.command == "migrate":
        db_path: Path = arguments.db

        def migrate_action() -> dict[str, object]:
            report = _migrate(db_path=db_path)
            _print_migration_report(report)
            return {
                "schemaVersion": report.schema_version,
                "appliedCount": len(report.applied),
            }

        return _run(command="migrate", correlation_id=correlation_id, action=migrate_action)

    def consolidate_action() -> dict[str, object]:
        return _summary_fields(_consolidate(arguments=arguments, run_id=correlation_id))

    return _run(command="consolidate", correlation_id=correlation_id, action=consolidate_action)
