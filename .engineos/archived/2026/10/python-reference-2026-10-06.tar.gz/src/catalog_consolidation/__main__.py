from catalog_consolidation.cli import main

raise SystemExit(main())
