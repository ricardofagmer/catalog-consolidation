import sqlite3
from collections.abc import Iterator
from typing import Final, TypeGuard, get_args

from catalog_consolidation.domain.limits import (
    BACKFILL_BATCH_SIZE,
    FUZZY_SCAN_BATCH_SIZE,
    MAX_EXACT_CANDIDATES,
)
from catalog_consolidation.domain.models import (
    CatalogProduct,
    FuzzyCandidate,
    MatchType,
    NewProduct,
    NewReviewItem,
    NewSellerLink,
    ProductKeySource,
    ReviewItem,
    ReviewReason,
    ReviewStatus,
    SellerLink,
)

_SELECT_BY_NORMALIZED_NAME: Final = """
SELECT Id, Name, Brand, Category, NormalizedName, NormalizedBrand FROM Product
WHERE NormalizedName = ? AND (? IS NULL OR NormalizedBrand IS NULL OR NormalizedBrand = ?)
ORDER BY Id LIMIT ?
"""

_SELECT_BRAND_COMPATIBLE_BATCH: Final = """
SELECT Id, NormalizedName FROM Product
WHERE NormalizedName IS NOT NULL AND (? IS NULL OR NormalizedBrand IS NULL OR NormalizedBrand = ?)
  AND Id > ?
ORDER BY Id LIMIT ?
"""

_SELECT_LINK_BY_SKU: Final = """
SELECT Id, SellerName, SellerProductId, ProductId, MatchType FROM SellerProduct
WHERE SellerName = ? AND SellerProductId = ?
"""

_SELECT_LINK_BY_SELLER_PRODUCT: Final = """
SELECT Id, SellerName, SellerProductId, ProductId, MatchType FROM SellerProduct
WHERE SellerName = ? AND ProductId = ?
"""

_SELECT_REVIEW_BY_SKU: Final = """
SELECT Id, SellerName, SellerProductId, CandidateProductId, Score, Reason, Status
FROM ProductMatchReview WHERE SellerName = ? AND SellerProductId = ?
"""

_INSERT_PRODUCT: Final = """
INSERT INTO Product (Name, Brand, Category, NormalizedName, NormalizedBrand) VALUES (?, ?, ?, ?, ?)
"""

_INSERT_LINK: Final = """
INSERT INTO SellerProduct
  (SellerName, ProductId, SellerProductId, SourceName, SourceBrand, SourceCategory, MatchType)
VALUES (?, ?, ?, ?, ?, ?, ?)
"""

_INSERT_REVIEW: Final = """
INSERT INTO ProductMatchReview
  (SellerName, SellerProductId, SourceName, SourceBrand, SourceCategory, CandidateProductId,
   Score, Reason)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
"""

_SELECT_MISSING_MATCH_KEYS_BATCH: Final = """
SELECT Id, Name, Brand FROM Product WHERE NormalizedName IS NULL AND Id > ? ORDER BY Id LIMIT ?
"""

_UPDATE_MATCH_KEYS: Final = """
UPDATE Product SET NormalizedName = ?, NormalizedBrand = ? WHERE Id = ?
"""

_MATCH_TYPES: Final[frozenset[str]] = frozenset(get_args(MatchType))
_REVIEW_REASONS: Final[frozenset[str]] = frozenset(get_args(ReviewReason))
_REVIEW_STATUSES: Final[frozenset[str]] = frozenset(get_args(ReviewStatus))

_Row = tuple[object, ...]


class SqliteCatalogRepository:
    """CatalogRepository over one sqlite3 connection; the unit of work owns the transaction."""

    def __init__(self, *, connection: sqlite3.Connection) -> None:
        self._connection = connection

    def find_by_normalized_name(
        self, *, normalized_name: str, normalized_brand: str | None
    ) -> tuple[CatalogProduct, ...]:
        rows = self._fetch_bounded(
            _SELECT_BY_NORMALIZED_NAME,
            (normalized_name, normalized_brand, normalized_brand, MAX_EXACT_CANDIDATES),
        )
        return tuple(_to_catalog_product(row) for row in rows)

    def list_brand_compatible(self, *, normalized_brand: str | None) -> Iterator[FuzzyCandidate]:
        # Each batch is fully read before yielding, so writes the caller makes between
        # batches on the same connection never interleave with an open cursor.
        after_id = 0
        while True:
            rows = self._fetch_bounded(
                _SELECT_BRAND_COMPATIBLE_BATCH,
                (normalized_brand, normalized_brand, after_id, FUZZY_SCAN_BATCH_SIZE),
            )
            for row in rows:
                yield FuzzyCandidate(product_id=_as_int(row[0]), normalized_name=_as_str(row[1]))
            if len(rows) < FUZZY_SCAN_BATCH_SIZE:
                return
            after_id = _as_int(rows[-1][0])

    def find_link_by_sku(self, *, seller_name: str, seller_product_id: str) -> SellerLink | None:
        row = self._fetch_one(_SELECT_LINK_BY_SKU, (seller_name, seller_product_id))
        return None if row is None else _to_seller_link(row)

    def find_link_by_seller_product(
        self, *, seller_name: str, product_id: int
    ) -> SellerLink | None:
        row = self._fetch_one(_SELECT_LINK_BY_SELLER_PRODUCT, (seller_name, product_id))
        return None if row is None else _to_seller_link(row)

    def find_review_by_sku(self, *, seller_name: str, seller_product_id: str) -> ReviewItem | None:
        row = self._fetch_one(_SELECT_REVIEW_BY_SKU, (seller_name, seller_product_id))
        return None if row is None else _to_review_item(row)

    def insert_product(self, product: NewProduct) -> int:
        return self._insert(
            _INSERT_PRODUCT,
            (
                product.name,
                product.brand,
                product.category,
                product.normalized_name,
                product.normalized_brand,
            ),
        )

    def insert_link(self, link: NewSellerLink) -> int:
        return self._insert(
            _INSERT_LINK,
            (
                link.seller_name,
                link.product_id,
                link.seller_product_id,
                link.source_name,
                link.source_brand,
                link.source_category,
                link.match_type,
            ),
        )

    def enqueue_review(self, review: NewReviewItem) -> int:
        return self._insert(
            _INSERT_REVIEW,
            (
                review.seller_name,
                review.seller_product_id,
                review.source_name,
                review.source_brand,
                review.source_category,
                review.candidate_product_id,
                review.score,
                review.reason,
            ),
        )

    def list_products_missing_match_keys(
        self, *, after_id: int, limit: int
    ) -> tuple[ProductKeySource, ...]:
        if not 1 <= limit <= BACKFILL_BATCH_SIZE:
            raise ValueError(f"limit must be between 1 and {BACKFILL_BATCH_SIZE}, got {limit}")
        rows = self._fetch_bounded(_SELECT_MISSING_MATCH_KEYS_BATCH, (after_id, limit))
        return tuple(
            ProductKeySource(
                product_id=_as_int(row[0]),
                name=_as_str(row[1]),
                brand=_as_optional_str(row[2]),
            )
            for row in rows
        )

    def set_match_keys(
        self, *, product_id: int, normalized_name: str, normalized_brand: str | None
    ) -> None:
        self._connection.execute(
            _UPDATE_MATCH_KEYS, (normalized_name, normalized_brand, product_id)
        )

    def _fetch_one(self, sql: str, params: tuple[object, ...]) -> _Row | None:
        row: _Row | None = self._connection.execute(sql, params).fetchone()
        return row

    def _fetch_bounded(self, sql: str, params: tuple[object, ...]) -> list[_Row]:
        # Only for statements carrying a LIMIT placeholder, so the result size is bounded.
        rows: list[_Row] = self._connection.execute(sql, params).fetchall()
        return rows

    def _insert(self, sql: str, params: tuple[object, ...]) -> int:
        row_id = self._connection.execute(sql, params).lastrowid
        if row_id is None:
            raise RuntimeError("sqlite returned no lastrowid after INSERT")
        return row_id


class SqliteUnitOfWork:
    """One transaction on one connection; the use case decides when it ends."""

    def __init__(self, *, connection: sqlite3.Connection) -> None:
        self._connection = connection
        self._catalog = SqliteCatalogRepository(connection=connection)
        self._changes_at_start = connection.total_changes

    @property
    def catalog(self) -> SqliteCatalogRepository:
        return self._catalog

    def commit(self) -> None:
        self._connection.commit()

    def rollback(self) -> None:
        self._connection.rollback()

    def rows_written(self) -> int:
        return self._connection.total_changes - self._changes_at_start


def _to_catalog_product(row: _Row) -> CatalogProduct:
    return CatalogProduct(
        id=_as_int(row[0]),
        name=_as_str(row[1]),
        brand=_as_optional_str(row[2]),
        category=_as_optional_str(row[3]),
        normalized_name=_as_optional_str(row[4]),
        normalized_brand=_as_optional_str(row[5]),
    )


def _to_seller_link(row: _Row) -> SellerLink:
    match_type = row[4]
    if not _is_match_type(match_type):
        raise ValueError(f"unexpected SellerProduct.MatchType: {match_type!r}")
    return SellerLink(
        id=_as_int(row[0]),
        seller_name=_as_str(row[1]),
        seller_product_id=_as_str(row[2]),
        product_id=_as_int(row[3]),
        match_type=match_type,
    )


def _to_review_item(row: _Row) -> ReviewItem:
    reason = row[5]
    status = row[6]
    if not _is_review_reason(reason):
        raise ValueError(f"unexpected ProductMatchReview.Reason: {reason!r}")
    if not _is_review_status(status):
        raise ValueError(f"unexpected ProductMatchReview.Status: {status!r}")
    return ReviewItem(
        id=_as_int(row[0]),
        seller_name=_as_str(row[1]),
        seller_product_id=_as_str(row[2]),
        candidate_product_id=_as_optional_int(row[3]),
        score=_as_optional_float(row[4]),
        reason=reason,
        status=status,
    )


def _is_match_type(value: object) -> TypeGuard[MatchType]:
    return isinstance(value, str) and value in _MATCH_TYPES


def _is_review_reason(value: object) -> TypeGuard[ReviewReason]:
    return isinstance(value, str) and value in _REVIEW_REASONS


def _is_review_status(value: object) -> TypeGuard[ReviewStatus]:
    return isinstance(value, str) and value in _REVIEW_STATUSES


def _as_int(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"expected INTEGER column value, got {type(value).__name__}")
    return value


def _as_optional_int(value: object) -> int | None:
    return None if value is None else _as_int(value)


def _as_str(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError(f"expected TEXT column value, got {type(value).__name__}")
    return value


def _as_optional_str(value: object) -> str | None:
    return None if value is None else _as_str(value)


def _as_optional_float(value: object) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise ValueError(f"expected REAL column value, got {type(value).__name__}")
    return float(value)
