import sqlite3
from pathlib import Path
from typing import Final

from catalog_consolidation.domain.errors import DatabaseFileError

REQUIRED_SCHEMA_VERSION: Final = 3

_BUSY_TIMEOUT_MS: Final = 5000
_MAIN_DATABASE_NAME: Final = "main"


def open_connection(db_path: Path) -> sqlite3.Connection:
    # sqlite3.connect would silently create an empty database for a mistyped path.
    if not db_path.is_file():
        raise DatabaseFileError(code="not_found", detail=f"database file not found: {db_path}")
    connection = sqlite3.connect(db_path, autocommit=True)
    # PRAGMAs run in autocommit mode: foreign_keys is a no-op inside an open transaction.
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute(f"PRAGMA busy_timeout = {_BUSY_TIMEOUT_MS}")
    # From here every statement runs inside a transaction that only commit()/rollback() ends,
    # and executescript no longer auto-commits.
    connection.autocommit = False
    return connection


def read_schema_version(connection: sqlite3.Connection) -> int:
    table = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", ("SchemaVersion",)
    ).fetchone()
    if table is None:
        return 0
    row = connection.execute("SELECT MAX(Version) FROM SchemaVersion").fetchone()
    if row is None or row[0] is None:
        return 0
    return int(row[0])


def require_schema_version(
    connection: sqlite3.Connection, *, required: int = REQUIRED_SCHEMA_VERSION
) -> None:
    current = read_schema_version(connection)
    if current < required:
        raise DatabaseFileError(
            code="schema_outdated",
            detail=(
                f"schema version {current} < required {required}; "
                f"run: python -m catalog_consolidation migrate --db {_database_path(connection)}"
            ),
        )


def _database_path(connection: sqlite3.Connection) -> str:
    for _seq, name, file in connection.execute("PRAGMA database_list"):
        if name == _MAIN_DATABASE_NAME:
            return str(file)
    return "<path>"
