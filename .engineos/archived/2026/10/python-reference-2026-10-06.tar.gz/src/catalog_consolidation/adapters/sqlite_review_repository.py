import sqlite3
from typing import Final, TypeGuard, get_args

from catalog_consolidation.adapters.sqlite_catalog_repository import SqliteCatalogRepository
from catalog_consolidation.domain.models import ReviewItem, ReviewReason, ReviewStatus
from catalog_consolidation.domain.ports import ReviewRecord
from catalog_consolidation.use_cases.resolve_review import REVIEW_PAGE_MAX_LIMIT

# The list use case asks for one look-ahead row past its largest page; nothing more.
_MAX_REVIEW_FETCH: Final = REVIEW_PAGE_MAX_LIMIT + 1

_REVIEW_COLUMNS: Final = (
    "Id, SellerName, SellerProductId, CandidateProductId, Score, Reason, Status, "
    "SourceName, SourceBrand, SourceCategory"
)

_SELECT_REVIEWS_BY_STATUS: Final = f"""
SELECT {_REVIEW_COLUMNS} FROM ProductMatchReview
WHERE Status = ? AND Id > ?
ORDER BY Id LIMIT ?
"""  # noqa: S608 - the interpolated value is a module constant; every value is a placeholder

_SELECT_REVIEW_BY_ID: Final = f"""
SELECT {_REVIEW_COLUMNS} FROM ProductMatchReview WHERE Id = ?
"""  # noqa: S608 - the interpolated value is a module constant; every value is a placeholder

_SELECT_PRODUCT_EXISTS: Final = "SELECT 1 FROM Product WHERE Id = ?"

_UPDATE_REVIEW_STATUS: Final = """
UPDATE ProductMatchReview SET Status = ? WHERE Id = ? AND Status = ?
"""

_REVIEW_REASONS: Final[frozenset[str]] = frozenset(get_args(ReviewReason))
_REVIEW_STATUSES: Final[frozenset[str]] = frozenset(get_args(ReviewStatus))

_Row = tuple[object, ...]


class SqliteReviewRepository:
    """ReviewRepository over one sqlite3 connection; the unit of work owns the transaction."""

    def __init__(self, *, connection: sqlite3.Connection) -> None:
        self._connection = connection

    def list_by_status(
        self, *, status: ReviewStatus, after_id: int, limit: int
    ) -> tuple[ReviewRecord, ...]:
        if not 1 <= limit <= _MAX_REVIEW_FETCH:
            raise ValueError(f"limit must be between 1 and {_MAX_REVIEW_FETCH}, got {limit}")
        rows: list[_Row] = self._connection.execute(
            _SELECT_REVIEWS_BY_STATUS, (status, after_id, limit)
        ).fetchall()
        return tuple(_to_review_record(row) for row in rows)

    def get(self, *, review_id: int) -> ReviewRecord | None:
        row: _Row | None = self._connection.execute(_SELECT_REVIEW_BY_ID, (review_id,)).fetchone()
        return None if row is None else _to_review_record(row)

    def product_exists(self, *, product_id: int) -> bool:
        row: _Row | None = self._connection.execute(
            _SELECT_PRODUCT_EXISTS, (product_id,)
        ).fetchone()
        return row is not None

    def transition_status(
        self, *, review_id: int, from_status: ReviewStatus, to_status: ReviewStatus
    ) -> bool:
        cursor = self._connection.execute(
            _UPDATE_REVIEW_STATUS, (to_status, review_id, from_status)
        )
        return cursor.rowcount == 1


class SqliteReviewUnitOfWork:
    """One transaction on one connection for a review command; the use case ends it."""

    def __init__(self, *, connection: sqlite3.Connection) -> None:
        self._connection = connection
        self._catalog = SqliteCatalogRepository(connection=connection)
        self._reviews = SqliteReviewRepository(connection=connection)

    @property
    def catalog(self) -> SqliteCatalogRepository:
        return self._catalog

    @property
    def reviews(self) -> SqliteReviewRepository:
        return self._reviews

    def commit(self) -> None:
        self._connection.commit()

    def rollback(self) -> None:
        self._connection.rollback()


def _to_review_record(row: _Row) -> ReviewRecord:
    reason = row[5]
    status = row[6]
    if not _is_review_reason(reason):
        raise ValueError(f"unexpected ProductMatchReview.Reason: {reason!r}")
    if not _is_review_status(status):
        raise ValueError(f"unexpected ProductMatchReview.Status: {status!r}")
    return ReviewRecord(
        item=ReviewItem(
            id=_as_int(row[0]),
            seller_name=_as_str(row[1]),
            seller_product_id=_as_str(row[2]),
            candidate_product_id=_as_optional_int(row[3]),
            score=_as_optional_float(row[4]),
            reason=reason,
            status=status,
        ),
        source_name=_as_str(row[7]),
        source_brand=_as_optional_str(row[8]),
        source_category=_as_optional_str(row[9]),
    )


def _is_review_reason(value: object) -> TypeGuard[ReviewReason]:
    return isinstance(value, str) and value in _REVIEW_REASONS


def _is_review_status(value: object) -> TypeGuard[ReviewStatus]:
    return isinstance(value, str) and value in _REVIEW_STATUSES


def _as_int(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"expected INTEGER column value, got {type(value).__name__}")
    return value


def _as_optional_int(value: object) -> int | None:
    return None if value is None else _as_int(value)


def _as_str(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError(f"expected TEXT column value, got {type(value).__name__}")
    return value


def _as_optional_str(value: object) -> str | None:
    return None if value is None else _as_str(value)


def _as_optional_float(value: object) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise ValueError(f"expected REAL column value, got {type(value).__name__}")
    return float(value)
