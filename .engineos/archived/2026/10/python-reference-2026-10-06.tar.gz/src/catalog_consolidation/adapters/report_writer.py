import json
import os
from collections.abc import Sequence
from pathlib import Path
from typing import Final

from catalog_consolidation.domain.limits import REPORT_SCORE_DECIMALS
from catalog_consolidation.domain.models import OUTCOME_CODES, EntryOutcome, RunSummary

_TEMP_SUFFIX: Final = ".tmp"
_CODE_COLUMN_WIDTH: Final = 26
_COUNT_COLUMN_WIDTH: Final = 6
_TOTAL_LABEL: Final = "TOTAL"


def to_report_record(outcome: EntryOutcome) -> dict[str, object]:
    # Key order is part of the frozen report contract; dicts preserve insertion order.
    return {
        "index": outcome.index,
        "sellerName": outcome.seller_name,
        "sellerProductId": outcome.seller_product_id,
        "outcome": outcome.outcome,
        "productId": outcome.product_id,
        "reviewReason": outcome.review_reason,
        "score": None if outcome.score is None else round(outcome.score, REPORT_SCORE_DECIMALS),
        "warnings": list(outcome.warnings),
        "errors": list(outcome.errors),
    }


def write_jsonl_report(*, path: Path, outcomes: Sequence[EntryOutcome]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(path.name + _TEMP_SUFFIX)
    try:
        with temp_path.open("w", encoding="utf-8", newline="\n") as handle:
            for outcome in outcomes:
                line = json.dumps(
                    to_report_record(outcome), ensure_ascii=False, separators=(",", ":")
                )
                handle.write(line + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        # A reader never sees a half-written report: the rename is atomic on one filesystem.
        os.replace(temp_path, path)
    except BaseException:
        temp_path.unlink(missing_ok=True)
        raise


def _format_count_line(label: str, count: int) -> str:
    return f"{label:<{_CODE_COLUMN_WIDTH}}{count:>{_COUNT_COLUMN_WIDTH}}"


def _format_bool(value: bool) -> str:
    return "true" if value else "false"


def format_summary(summary: RunSummary) -> str:
    header = (
        f"run {summary.run_id} input={summary.input_label}"
        f" dry_run={_format_bool(summary.dry_run)}"
        f" committed={_format_bool(summary.committed)}"
        f" rows_written={summary.rows_written}"
    )
    # Iterate the vocabulary, not summary.counts, so all eight codes print in frozen order.
    counts = dict(summary.counts)
    count_lines = [_format_count_line(code, counts.get(code, 0)) for code in OUTCOME_CODES]
    total_line = _format_count_line(_TOTAL_LABEL, summary.total)
    return "\n".join([header, *count_lines, total_line])
