import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Final, TypeGuard

from catalog_consolidation.domain.errors import InvalidInputFileError
from catalog_consolidation.domain.limits import (
    MAX_BRAND_LENGTH,
    MAX_CATEGORY_LENGTH,
    MAX_INPUT_ENTRIES,
    MAX_INPUT_FILE_BYTES,
    MAX_NAME_LENGTH,
    MAX_SELLER_NAME_LENGTH,
    MAX_SELLER_PRODUCT_ID_LENGTH,
    SELLER_PRODUCT_ID_PATTERN,
    UUID_PATTERN,
)
from catalog_consolidation.domain.models import (
    FieldName,
    FieldViolation,
    RejectedEntry,
    SellerEntry,
    WarningCode,
)

_ID_FIELD: Final = "Id"
_SELLER_NAME_FIELD: Final = "SellerName"
_NAME_FIELD: Final = "Name"
_BRAND_FIELD: Final = "Brand"
_CATEGORY_FIELD: Final = "Category"
_KNOWN_FIELDS: Final = frozenset(
    {_ID_FIELD, _SELLER_NAME_FIELD, _NAME_FIELD, _BRAND_FIELD, _CATEGORY_FIELD}
)
_SELLER_PRODUCT_ID_REGEX: Final = re.compile(SELLER_PRODUCT_ID_PATTERN)
_UUID_REGEX: Final = re.compile(UUID_PATTERN)
_INPUT_ENCODING: Final = "utf-8-sig"


@dataclass(frozen=True)
class _FieldResult:
    value: str | None
    violation: FieldViolation | None


class JsonEntryReader:
    """Reads a seller JSON array and validates every record at the boundary.

    File-level problems abort the run with InvalidInputFileError; record-level problems
    become RejectedEntry values so one bad record never hides the others.
    """

    def __init__(
        self,
        *,
        path: Path,
        max_bytes: int = MAX_INPUT_FILE_BYTES,
        max_entries: int = MAX_INPUT_ENTRIES,
    ) -> None:
        if max_bytes < 0 or max_entries < 0:
            raise ValueError("max_bytes and max_entries must be non-negative")
        self._path = path
        self._max_bytes = max_bytes
        self._max_entries = max_entries

    def read(self) -> tuple[SellerEntry | RejectedEntry, ...]:
        records = self._load_records()
        return tuple(_validate_record(index, record) for index, record in enumerate(records))

    def _load_records(self) -> list[object]:
        raw = self._read_bounded_bytes()
        try:
            text = raw.decode(_INPUT_ENCODING)
        except UnicodeDecodeError as error:
            raise InvalidInputFileError(
                code="not_utf8",
                detail=f"{self._path}: invalid UTF-8 at byte offset {error.start}",
            ) from None
        try:
            document: object = json.loads(text, parse_constant=_reject_non_standard_constant)
        except RecursionError:
            raise InvalidInputFileError(
                code="not_json", detail=f"{self._path}: JSON nesting too deep"
            ) from None
        except json.JSONDecodeError as error:
            # Only the position is reported: the message must never echo seller text.
            raise InvalidInputFileError(
                code="not_json",
                detail=f"{self._path}: invalid JSON at line {error.lineno} column {error.colno}",
            ) from None
        except ValueError:
            raise InvalidInputFileError(
                code="not_json", detail=f"{self._path}: invalid JSON"
            ) from None
        if not _is_json_array(document):
            raise InvalidInputFileError(
                code="not_an_array", detail=f"{self._path}: top-level value is not a JSON array"
            )
        if len(document) > self._max_entries:
            raise InvalidInputFileError(
                code="too_many_entries",
                detail=f"{self._path}: {len(document)} entries > limit {self._max_entries}",
            )
        return document

    def _read_bounded_bytes(self) -> bytes:
        try:
            if not self._path.is_file():
                raise InvalidInputFileError(
                    code="unreadable", detail=f"{self._path}: not a readable file"
                )
            size = self._path.stat().st_size
            if size > self._max_bytes:
                raise self._too_large(size)
            with self._path.open("rb") as handle:
                # One byte past the limit detects a file that grew between stat and read.
                raw = handle.read(self._max_bytes + 1)
        except OSError:
            raise InvalidInputFileError(
                code="unreadable", detail=f"{self._path}: not a readable file"
            ) from None
        if len(raw) > self._max_bytes:
            raise self._too_large(len(raw))
        return raw

    def _too_large(self, size: int) -> InvalidInputFileError:
        return InvalidInputFileError(
            code="too_large",
            detail=f"{self._path}: {size} bytes > limit {self._max_bytes}",
        )


def _reject_non_standard_constant(constant: str) -> object:
    # NaN and Infinity are not JSON (RFC 8259); the stdlib accepts them unless told not to.
    raise ValueError(f"non-standard JSON constant {constant}")


def _is_json_array(value: object) -> TypeGuard[list[object]]:
    return isinstance(value, list)


def _is_json_object(value: object) -> TypeGuard[dict[str, object]]:
    # json.loads only produces string keys; the check keeps the narrowing honest.
    return isinstance(value, dict) and all(
        isinstance(key, str)
        for key in value  # pyright: ignore[reportUnknownVariableType]
    )


def _validate_record(index: int, record: object) -> SellerEntry | RejectedEntry:
    if not _is_json_object(record):
        return RejectedEntry(
            index=index,
            seller_name=None,
            seller_product_id=None,
            violations=(FieldViolation("record", "not_an_object"),),
            warnings=(),
        )
    seller_product_id = _seller_product_id(record)
    seller_name = _required_text(
        record, field=_SELLER_NAME_FIELD, max_length=MAX_SELLER_NAME_LENGTH
    )
    name = _required_text(record, field=_NAME_FIELD, max_length=MAX_NAME_LENGTH)
    brand = _optional_text(record, field=_BRAND_FIELD, max_length=MAX_BRAND_LENGTH)
    category = _optional_text(record, field=_CATEGORY_FIELD, max_length=MAX_CATEGORY_LENGTH)

    warnings: list[WarningCode] = []
    sku = seller_product_id.value
    if sku is not None and _UUID_REGEX.fullmatch(sku) is None:
        warnings.append("non_uuid_seller_sku")
    if _is_blank_text(record.get(_BRAND_FIELD)) and brand.violation is None:
        warnings.append("blank_brand_treated_as_null")
    if _is_blank_text(record.get(_CATEGORY_FIELD)) and category.violation is None:
        warnings.append("blank_category_treated_as_null")
    if not record.keys() <= _KNOWN_FIELDS:
        warnings.append("unknown_fields_ignored")

    violations = tuple(
        result.violation
        for result in (seller_product_id, seller_name, name, brand, category)
        if result.violation is not None
    )
    stripped_seller_name = seller_name.value.strip() if seller_name.value is not None else None
    if violations:
        return RejectedEntry(
            index=index,
            seller_name=stripped_seller_name,
            seller_product_id=seller_product_id.value,
            violations=violations,
            warnings=tuple(warnings),
        )
    # Unreachable when violations is empty; the checks narrow the types for the constructor.
    if stripped_seller_name is None or seller_product_id.value is None or name.value is None:
        raise AssertionError("required field accepted without a value")
    return SellerEntry(
        index=index,
        seller_name=stripped_seller_name,
        seller_product_id=seller_product_id.value,
        name=name.value,
        brand=brand.value,
        category=category.value,
        warnings=tuple(warnings),
    )


def _seller_product_id(fields: dict[str, object]) -> _FieldResult:
    result = _required_text(fields, field=_ID_FIELD, max_length=MAX_SELLER_PRODUCT_ID_LENGTH)
    if result.value is not None and _SELLER_PRODUCT_ID_REGEX.fullmatch(result.value) is None:
        return _FieldResult(None, FieldViolation(_ID_FIELD, "invalid_charset"))
    return result


def _required_text(fields: dict[str, object], *, field: FieldName, max_length: int) -> _FieldResult:
    if field not in fields:
        return _FieldResult(None, FieldViolation(field, "missing"))
    value = fields[field]
    if not isinstance(value, str):
        return _FieldResult(None, FieldViolation(field, "not_a_string"))
    if not value.strip():
        return _FieldResult(None, FieldViolation(field, "blank"))
    if len(value) > max_length:
        return _FieldResult(None, FieldViolation(field, "too_long"))
    return _FieldResult(value, None)


def _optional_text(fields: dict[str, object], *, field: FieldName, max_length: int) -> _FieldResult:
    value = fields.get(field)
    if value is None:
        return _FieldResult(None, None)
    if not isinstance(value, str):
        return _FieldResult(None, FieldViolation(field, "not_a_string"))
    if len(value) > max_length:
        return _FieldResult(None, FieldViolation(field, "too_long"))
    if not value.strip():
        return _FieldResult(None, None)
    return _FieldResult(value, None)


def _is_blank_text(value: object) -> bool:
    return isinstance(value, str) and not value.strip()
