"""Forward-only schema migrations: discovery, checksum guard, backup, apply and backfill."""

import hashlib
import re
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Final

from catalog_consolidation.adapters.sqlite_connection import read_schema_version
from catalog_consolidation.domain.errors import MigrationError
from catalog_consolidation.domain.limits import BACKFILL_BATCH_SIZE
from catalog_consolidation.domain.normalization import normalize

_FILENAME_PATTERN: Final = re.compile(r"(\d{4})_([a-z0-9_]+)\.sql")
_SELLER_PRODUCT_REBUILD_VERSION: Final = 1
_MATCH_KEYS_VERSION: Final = 2
_BACKUP_TIMESTAMP_FORMAT: Final = "%Y%m%dT%H%M%SZ"
# AUTOINCREMENT ids start at 1, so 0 sits below every row of the keyset scan.
_KEYSET_START: Final = 0

_CREATE_SCHEMA_VERSION: Final = """
CREATE TABLE IF NOT EXISTS SchemaVersion (
  Version   INTEGER PRIMARY KEY,
  Name      TEXT NOT NULL,
  Checksum  TEXT NOT NULL,
  AppliedAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)
"""
_SELECT_TABLE: Final = "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?"
_SELECT_APPLIED: Final = "SELECT Version, Checksum FROM SchemaVersion ORDER BY Version"
_INSERT_APPLIED: Final = "INSERT INTO SchemaVersion (Version, Name, Checksum) VALUES (?, ?, ?)"
_COUNT_SELLER_PRODUCTS: Final = "SELECT COUNT(*) FROM SellerProduct"
_SELECT_PRODUCT_BATCH: Final = (
    "SELECT Id, Name, Brand FROM Product WHERE Id > ? ORDER BY Id LIMIT ?"
)
_UPDATE_MATCH_KEYS: Final = (
    "UPDATE Product SET NormalizedName = ?, NormalizedBrand = ? WHERE Id = ?"
)


@dataclass(frozen=True)
class MigrationFile:
    version: int
    name: str
    path: Path
    checksum: str


@dataclass(frozen=True)
class AppliedMigration:
    version: int
    name: str
    backfilled_rows: int | None


@dataclass(frozen=True)
class MigrationReport:
    backup_path: Path | None
    applied: tuple[AppliedMigration, ...]
    schema_version: int


def default_migrations_dir() -> Path:
    return Path(__file__).resolve().parents[3] / "migrations"


class SqliteMigrationRunner:
    def __init__(
        self, *, connection: sqlite3.Connection, db_path: Path, migrations_dir: Path
    ) -> None:
        self._connection = connection
        self._db_path = db_path
        self._migrations_dir = migrations_dir

    def pending(self) -> tuple[MigrationFile, ...]:
        """Read-only: discovers files, verifies applied checksums, returns what is left."""
        files = _discover(self._migrations_dir)
        applied = self._applied_checksums()
        _verify_applied(files, applied)
        return tuple(migration for migration in files if migration.version not in applied)

    def apply_pending(self) -> MigrationReport:
        pending = self.pending()
        # pending() only read; end that transaction so the backup and the first migration
        # start from a clean state.
        self._connection.rollback()
        if not pending:
            return MigrationReport(
                backup_path=None, applied=(), schema_version=self._current_version()
            )
        backup_path = self._backup()
        applied = tuple(self._apply(migration) for migration in pending)
        return MigrationReport(
            backup_path=backup_path, applied=applied, schema_version=self._current_version()
        )

    def _current_version(self) -> int:
        version = read_schema_version(self._connection)
        self._connection.rollback()
        return version

    def _applied_checksums(self) -> dict[int, str]:
        if self._connection.execute(_SELECT_TABLE, ("SchemaVersion",)).fetchone() is None:
            return {}
        return {
            int(version): str(checksum)
            for version, checksum in self._connection.execute(_SELECT_APPLIED)
        }

    def _backup(self) -> Path:
        # Migrations are forward-only; this file is the recovery path if one goes wrong.
        stamp = datetime.now(UTC).strftime(_BACKUP_TIMESTAMP_FORMAT)
        backup_path = self._db_path.with_name(f"{self._db_path.name}.pre-migrate-{stamp}.bak")
        if backup_path.exists():
            raise FileExistsError(f"refusing to overwrite existing backup: {backup_path}")
        with closing(sqlite3.connect(backup_path)) as target:
            self._connection.backup(target)
        return backup_path

    def _apply(self, migration: MigrationFile) -> AppliedMigration:
        script = _read_verified_script(migration)
        try:
            self._connection.execute(_CREATE_SCHEMA_VERSION)
            rows_before = (
                self._count_seller_products()
                if migration.version == _SELLER_PRODUCT_REBUILD_VERSION
                else None
            )
            self._connection.executescript(script)
            if rows_before is not None:
                self._ensure_seller_products_preserved(rows_before)
            backfilled_rows = (
                self._backfill_match_keys() if migration.version == _MATCH_KEYS_VERSION else None
            )
            self._connection.execute(
                _INSERT_APPLIED, (migration.version, migration.name, migration.checksum)
            )
            self._connection.commit()
        except BaseException:
            self._connection.rollback()
            raise
        return AppliedMigration(
            version=migration.version, name=migration.name, backfilled_rows=backfilled_rows
        )

    def _count_seller_products(self) -> int:
        row = self._connection.execute(_COUNT_SELLER_PRODUCTS).fetchone()
        return int(row[0]) if row is not None else 0

    def _ensure_seller_products_preserved(self, rows_before: int) -> None:
        # 0001 copies links with an inner JOIN to Product: an orphan link would vanish silently.
        rows_after = self._count_seller_products()
        if rows_after != rows_before:
            raise MigrationError(
                code="rows_lost",
                detail=(
                    f"row count mismatch in migration {_SELLER_PRODUCT_REBUILD_VERSION:04d}: "
                    f"SellerProduct had {rows_before} rows before and {rows_after} after; "
                    "orphan links reference a missing Product. Rolled back."
                ),
            )

    def _backfill_match_keys(self) -> int:
        after_id = _KEYSET_START
        updated = 0
        while True:
            rows = self._connection.execute(
                _SELECT_PRODUCT_BATCH, (after_id, BACKFILL_BATCH_SIZE)
            ).fetchall()
            if not rows:
                return updated
            batch = [
                (normalize(_text_or_none(name)), normalize(_text_or_none(brand)), int(product_id))
                for product_id, name, brand in rows
            ]
            self._connection.executemany(_UPDATE_MATCH_KEYS, batch)
            updated += len(batch)
            after_id = batch[-1][2]


def _discover(directory: Path) -> tuple[MigrationFile, ...]:
    if not directory.is_dir():
        raise MigrationError(
            code="version_gap", detail=f"migrations directory not found: {directory}"
        )
    files: list[MigrationFile] = []
    for path in directory.glob("*.sql"):
        match = _FILENAME_PATTERN.fullmatch(path.name)
        if match is None:
            raise MigrationError(
                code="invalid_filename", detail=f"{path.name} does not match NNNN_name.sql"
            )
        files.append(
            MigrationFile(
                version=int(match.group(1)),
                name=match.group(2),
                path=path,
                checksum=hashlib.sha256(path.read_bytes()).hexdigest(),
            )
        )
    files.sort(key=lambda migration: migration.version)
    versions = tuple(migration.version for migration in files)
    if not versions or versions != tuple(range(1, len(versions) + 1)):
        raise MigrationError(
            code="version_gap",
            detail=f"versions must run contiguously from 1, found {versions} in {directory}",
        )
    return tuple(files)


def _verify_applied(files: tuple[MigrationFile, ...], applied: dict[int, str]) -> None:
    by_version = {migration.version: migration for migration in files}
    for version, checksum in applied.items():
        migration = by_version.get(version)
        if migration is None:
            raise MigrationError(
                code="version_gap",
                detail=f"database has version {version} applied but no migration file for it",
            )
        if migration.checksum != checksum:
            raise MigrationError(
                code="checksum_mismatch",
                detail=f"{migration.path.name} was edited after it was applied",
            )


def _read_verified_script(migration: MigrationFile) -> str:
    content = migration.path.read_bytes()
    if hashlib.sha256(content).hexdigest() != migration.checksum:
        raise MigrationError(
            code="checksum_mismatch",
            detail=f"{migration.path.name} changed between discovery and apply",
        )
    return content.decode("utf-8")


def _text_or_none(value: object) -> str | None:
    return value if isinstance(value, str) else None
