"""Consolidate one seller file into the catalog inside a single transaction (frozen rule G)."""

from collections import Counter

from catalog_consolidation.domain.limits import BACKFILL_BATCH_SIZE
from catalog_consolidation.domain.matching import match_entry
from catalog_consolidation.domain.models import (
    OUTCOME_CODES,
    ConsolidationResult,
    CreateDecision,
    EntryOutcome,
    HoldDecision,
    LinkDecision,
    MatchQuery,
    MatchType,
    NewProduct,
    NewReviewItem,
    NewSellerLink,
    OutcomeCode,
    RejectedEntry,
    ReviewItem,
    ReviewReason,
    RunSummary,
    SellerEntry,
    SellerLink,
    WarningCode,
)
from catalog_consolidation.domain.normalization import clean_display, normalize
from catalog_consolidation.domain.ports import CatalogRepository, EntrySource, UnitOfWork

_UNNORMALIZABLE_NAME_ERROR = "unnormalizable:Name"


class ConsolidateFile:
    def __init__(
        self, *, unit_of_work: UnitOfWork, entry_source: EntrySource, input_label: str, run_id: str
    ) -> None:
        self._unit_of_work = unit_of_work
        self._entry_source = entry_source
        self._input_label = input_label
        self._run_id = run_id

    def execute(self, *, dry_run: bool) -> ConsolidationResult:
        # Read before the transaction starts: an invalid file writes nothing.
        entries = self._entry_source.read()
        try:
            self._heal_match_keys()
            outcomes = tuple(self._consolidate(item) for item in entries)
            rows_written = self._unit_of_work.rows_written()
            if not dry_run:
                self._unit_of_work.commit()
        except Exception:
            self._unit_of_work.rollback()
            raise
        if dry_run:
            self._unit_of_work.rollback()
        return ConsolidationResult(
            outcomes=outcomes,
            summary=self._summarize(outcomes=outcomes, rows_written=rows_written, dry_run=dry_run),
        )

    @property
    def _catalog(self) -> CatalogRepository:
        return self._unit_of_work.catalog

    def _heal_match_keys(self) -> None:
        # Products written by other tools carry NULL match keys and would be invisible to
        # matching. A name that normalizes to nothing stays NULL so a re-run writes 0 rows.
        after_id = 0
        while True:
            batch = self._catalog.list_products_missing_match_keys(
                after_id=after_id, limit=BACKFILL_BATCH_SIZE
            )
            for source in batch:
                normalized_name = normalize(source.name)
                if normalized_name is not None:
                    self._catalog.set_match_keys(
                        product_id=source.product_id,
                        normalized_name=normalized_name,
                        normalized_brand=normalize(source.brand),
                    )
            if len(batch) < BACKFILL_BATCH_SIZE:
                return
            after_id = batch[-1].product_id

    def _consolidate(self, item: SellerEntry | RejectedEntry) -> EntryOutcome:
        if isinstance(item, RejectedEntry):
            return _rejected_outcome(item)
        normalized_name = normalize(item.name)
        if normalized_name is None:
            return _outcome(item, outcome="REJECTED_INVALID", errors=(_UNNORMALIZABLE_NAME_ERROR,))
        query = MatchQuery(
            raw_name=item.name,
            normalized_name=normalized_name,
            normalized_brand=normalize(item.brand),
        )
        link = self._catalog.find_link_by_sku(
            seller_name=item.seller_name, seller_product_id=item.seller_product_id
        )
        if link is not None:
            return self._recheck_existing_link(entry=item, query=query, link=link)
        review = self._catalog.find_review_by_sku(
            seller_name=item.seller_name, seller_product_id=item.seller_product_id
        )
        if review is not None:
            return _pending_review_outcome(entry=item, review=review)
        decision = match_entry(query=query, catalog=self._catalog)
        if isinstance(decision, HoldDecision):
            return self._hold(entry=item, decision=decision)
        if isinstance(decision, CreateDecision):
            return self._create(entry=item, query=query, decision=decision)
        return self._link(entry=item, decision=decision)

    def _recheck_existing_link(
        self, *, entry: SellerEntry, query: MatchQuery, link: SellerLink
    ) -> EntryOutcome:
        # A human-confirmed link is authoritative: the automatic matcher never links fuzzy
        # candidates, so re-matching it would report a false conflict on every re-run.
        if link.match_type == "REVIEWED":
            return _outcome(entry, outcome="UNCHANGED", product_id=link.product_id)
        decision = match_entry(query=query, catalog=self._catalog)
        if isinstance(decision, LinkDecision) and decision.product_id == link.product_id:
            return _outcome(entry, outcome="UNCHANGED", product_id=link.product_id)
        return _outcome(entry, outcome="CONFLICT_SELLER_SKU", product_id=link.product_id)

    def _hold(self, *, entry: SellerEntry, decision: HoldDecision) -> EntryOutcome:
        self._catalog.enqueue_review(
            NewReviewItem(
                seller_name=entry.seller_name,
                seller_product_id=entry.seller_product_id,
                source_name=entry.name,
                source_brand=entry.brand,
                source_category=entry.category,
                candidate_product_id=decision.candidate_product_id,
                score=decision.score,
                reason=decision.reason,
            )
        )
        extra: tuple[WarningCode, ...] = (
            ("ambiguous_candidates",) if decision.reason == "AMBIGUOUS" else ()
        )
        return _outcome(
            entry,
            outcome="HELD_FOR_REVIEW",
            product_id=decision.candidate_product_id,
            review_reason=decision.reason,
            score=decision.score,
            extra_warnings=extra,
        )

    def _create(
        self, *, entry: SellerEntry, query: MatchQuery, decision: CreateDecision
    ) -> EntryOutcome:
        product_id = self._catalog.insert_product(
            NewProduct(
                name=_required_display(entry.name),
                brand=clean_display(entry.brand),
                category=clean_display(entry.category),
                normalized_name=query.normalized_name,
                normalized_brand=query.normalized_brand,
            )
        )
        self._catalog.insert_link(
            _new_link(entry=entry, product_id=product_id, match_type="CREATED")
        )
        return _outcome(entry, outcome="CREATED", product_id=product_id, score=decision.best_score)

    def _link(self, *, entry: SellerEntry, decision: LinkDecision) -> EntryOutcome:
        existing = self._catalog.find_link_by_seller_product(
            seller_name=entry.seller_name, product_id=decision.product_id
        )
        if existing is not None:
            return _outcome(
                entry, outcome="SKIPPED_DUPLICATE_LISTING", product_id=decision.product_id
            )
        self._catalog.insert_link(
            _new_link(entry=entry, product_id=decision.product_id, match_type=decision.match_type)
        )
        outcome: OutcomeCode = (
            "LINKED_EXACT" if decision.match_type == "EXACT" else "LINKED_NORMALIZED"
        )
        return _outcome(entry, outcome=outcome, product_id=decision.product_id)

    def _summarize(
        self, *, outcomes: tuple[EntryOutcome, ...], rows_written: int, dry_run: bool
    ) -> RunSummary:
        counts = Counter(outcome.outcome for outcome in outcomes)
        return RunSummary(
            run_id=self._run_id,
            input_label=self._input_label,
            total=len(outcomes),
            counts=tuple((code, counts[code]) for code in OUTCOME_CODES),
            rows_written=rows_written,
            dry_run=dry_run,
            committed=not dry_run,
        )


def _required_display(name: str) -> str:
    display = clean_display(name)
    # Unreachable in practice: a name that normalizes to a value is never blank.
    if display is None:
        raise ValueError("a normalizable name has no display form")
    return display


def _new_link(*, entry: SellerEntry, product_id: int, match_type: MatchType) -> NewSellerLink:
    return NewSellerLink(
        seller_name=entry.seller_name,
        seller_product_id=entry.seller_product_id,
        product_id=product_id,
        source_name=entry.name,
        source_brand=entry.brand,
        source_category=entry.category,
        match_type=match_type,
    )


def _pending_review_outcome(*, entry: SellerEntry, review: ReviewItem) -> EntryOutcome:
    extra: tuple[WarningCode, ...] = (
        ("review_previously_rejected",) if review.status == "REJECTED" else ()
    )
    return _outcome(
        entry,
        outcome="HELD_FOR_REVIEW",
        product_id=review.candidate_product_id,
        review_reason=review.reason,
        score=review.score,
        extra_warnings=extra,
    )


def _rejected_outcome(entry: RejectedEntry) -> EntryOutcome:
    return EntryOutcome(
        index=entry.index,
        seller_name=entry.seller_name,
        seller_product_id=entry.seller_product_id,
        outcome="REJECTED_INVALID",
        product_id=None,
        review_reason=None,
        score=None,
        warnings=entry.warnings,
        errors=tuple(f"{violation.code}:{violation.field}" for violation in entry.violations),
    )


def _outcome(
    entry: SellerEntry,
    *,
    outcome: OutcomeCode,
    product_id: int | None = None,
    review_reason: ReviewReason | None = None,
    score: float | None = None,
    extra_warnings: tuple[WarningCode, ...] = (),
    errors: tuple[str, ...] = (),
) -> EntryOutcome:
    return EntryOutcome(
        index=entry.index,
        seller_name=entry.seller_name,
        seller_product_id=entry.seller_product_id,
        outcome=outcome,
        product_id=product_id,
        review_reason=review_reason,
        score=score,
        warnings=entry.warnings + extra_warnings,
        errors=errors,
    )
