"""List the review queue and resolve one row, each inside a single transaction (ADR 0004)."""

from dataclasses import dataclass
from typing import Final, Literal

from catalog_consolidation.domain.errors import DomainError
from catalog_consolidation.domain.models import MatchType, NewProduct, NewSellerLink, ReviewStatus
from catalog_consolidation.domain.normalization import clean_display, normalize
from catalog_consolidation.domain.ports import ReviewRecord, ReviewUnitOfWork

REVIEW_PAGE_DEFAULT_LIMIT: Final = 20
REVIEW_PAGE_MAX_LIMIT: Final = 100

ReviewResolutionErrorCode = Literal[
    "review_not_found",
    "review_not_pending",
    "product_not_found",
    "seller_sku_already_linked",
    "seller_already_linked_to_product",
    "source_name_unnormalizable",
]


class ReviewResolutionError(DomainError):
    """A resolution the queue row or the catalog does not allow; nothing was written."""

    def __init__(self, *, code: ReviewResolutionErrorCode, detail: str) -> None:
        super().__init__(f"{code}: {detail}")
        self.code: ReviewResolutionErrorCode = code
        self.detail = detail  # ids and statuses only, never seller-supplied text


@dataclass(frozen=True)
class ReviewPage:
    records: tuple[ReviewRecord, ...]
    next_after_id: int | None  # set when more rows exist past this page


@dataclass(frozen=True)
class CreateProduct:
    review_id: int


@dataclass(frozen=True)
class RejectReview:
    review_id: int


@dataclass(frozen=True)
class LinkToProduct:
    review_id: int
    product_id: int


ResolveCommand = CreateProduct | RejectReview | LinkToProduct


@dataclass(frozen=True)
class ResolutionResult:
    review_id: int
    status: ReviewStatus
    product_id: int | None  # the product the seller is now linked to; None on reject
    link_id: int | None  # the new SellerProduct row; None on reject


class ListReviews:
    def __init__(self, *, unit_of_work: ReviewUnitOfWork) -> None:
        self._unit_of_work = unit_of_work

    def execute(self, *, status: ReviewStatus, after_id: int, limit: int) -> ReviewPage:
        if not 1 <= limit <= REVIEW_PAGE_MAX_LIMIT:
            raise ValueError(f"limit must be between 1 and {REVIEW_PAGE_MAX_LIMIT}, got {limit}")
        try:
            # One look-ahead row tells whether a next page exists without a COUNT query.
            records = self._unit_of_work.reviews.list_by_status(
                status=status, after_id=after_id, limit=limit + 1
            )
        finally:
            # Read-only: end the implicit transaction instead of holding it open.
            self._unit_of_work.rollback()
        page = records[:limit]
        has_more = len(records) > limit
        return ReviewPage(records=page, next_after_id=page[-1].item.id if has_more else None)


class ResolveReview:
    def __init__(self, *, unit_of_work: ReviewUnitOfWork) -> None:
        self._unit_of_work = unit_of_work

    def execute(self, command: ResolveCommand) -> ResolutionResult:
        try:
            result = self._resolve(command)
            self._unit_of_work.commit()
        except Exception:
            self._unit_of_work.rollback()
            raise
        return result

    def _resolve(self, command: ResolveCommand) -> ResolutionResult:
        record = self._pending_record(command.review_id)
        if isinstance(command, RejectReview):
            self._transition(record, to_status="REJECTED")
            return ResolutionResult(
                review_id=record.item.id, status="REJECTED", product_id=None, link_id=None
            )
        self._require_sku_unlinked(record)
        if isinstance(command, CreateProduct):
            product_id = self._unit_of_work.catalog.insert_product(_new_product(record))
            link_id = self._link(record, product_id=product_id, match_type="CREATED")
            self._transition(record, to_status="CREATED")
            return ResolutionResult(
                review_id=record.item.id, status="CREATED", product_id=product_id, link_id=link_id
            )
        if not self._unit_of_work.reviews.product_exists(product_id=command.product_id):
            raise ReviewResolutionError(
                code="product_not_found", detail=f"product {command.product_id} does not exist"
            )
        self._require_seller_not_on_product(record, product_id=command.product_id)
        link_id = self._link(record, product_id=command.product_id, match_type="REVIEWED")
        self._transition(record, to_status="LINKED")
        return ResolutionResult(
            review_id=record.item.id,
            status="LINKED",
            product_id=command.product_id,
            link_id=link_id,
        )

    def _pending_record(self, review_id: int) -> ReviewRecord:
        record = self._unit_of_work.reviews.get(review_id=review_id)
        if record is None:
            raise ReviewResolutionError(
                code="review_not_found", detail=f"review {review_id} does not exist"
            )
        if record.item.status != "PENDING":
            raise ReviewResolutionError(
                code="review_not_pending",
                detail=f"review {review_id} is {record.item.status}, only PENDING can be resolved",
            )
        return record

    def _require_sku_unlinked(self, record: ReviewRecord) -> None:
        existing = self._unit_of_work.catalog.find_link_by_sku(
            seller_name=record.item.seller_name,
            seller_product_id=record.item.seller_product_id,
        )
        if existing is not None:
            raise ReviewResolutionError(
                code="seller_sku_already_linked",
                detail=(
                    f"review {record.item.id}: seller SKU already linked to product "
                    f"{existing.product_id} (link {existing.id})"
                ),
            )

    def _require_seller_not_on_product(self, record: ReviewRecord, *, product_id: int) -> None:
        existing = self._unit_of_work.catalog.find_link_by_seller_product(
            seller_name=record.item.seller_name, product_id=product_id
        )
        if existing is not None:
            raise ReviewResolutionError(
                code="seller_already_linked_to_product",
                detail=(
                    f"review {record.item.id}: seller already linked to product {product_id} "
                    f"(link {existing.id})"
                ),
            )

    def _link(self, record: ReviewRecord, *, product_id: int, match_type: MatchType) -> int:
        return self._unit_of_work.catalog.insert_link(
            NewSellerLink(
                seller_name=record.item.seller_name,
                seller_product_id=record.item.seller_product_id,
                product_id=product_id,
                source_name=record.source_name,
                source_brand=record.source_brand,
                source_category=record.source_category,
                match_type=match_type,
            )
        )

    def _transition(self, record: ReviewRecord, *, to_status: ReviewStatus) -> None:
        moved = self._unit_of_work.reviews.transition_status(
            review_id=record.item.id, from_status="PENDING", to_status=to_status
        )
        if not moved:
            # Another resolver changed the row between the read and this write.
            raise ReviewResolutionError(
                code="review_not_pending",
                detail=f"review {record.item.id} is no longer PENDING",
            )


def _new_product(record: ReviewRecord) -> NewProduct:
    name = clean_display(record.source_name)
    normalized_name = normalize(record.source_name)
    # Unreachable for rows the consolidator queued: it rejects unnormalizable names first.
    if name is None or normalized_name is None:
        raise ReviewResolutionError(
            code="source_name_unnormalizable",
            detail=f"review {record.item.id}: source name has no normalized form",
        )
    return NewProduct(
        name=name,
        brand=clean_display(record.source_brand),
        category=clean_display(record.source_category),
        normalized_name=normalized_name,
        normalized_brand=normalize(record.source_brand),
    )
