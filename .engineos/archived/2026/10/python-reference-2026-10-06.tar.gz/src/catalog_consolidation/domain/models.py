from dataclasses import dataclass
from typing import Final, Literal

OutcomeCode = Literal[
    "LINKED_EXACT",
    "LINKED_NORMALIZED",
    "CREATED",
    "UNCHANGED",
    "SKIPPED_DUPLICATE_LISTING",
    "HELD_FOR_REVIEW",
    "REJECTED_INVALID",
    "CONFLICT_SELLER_SKU",
]
# Fixed order used by the stdout summary and by every count table.
OUTCOME_CODES: Final[tuple[OutcomeCode, ...]] = (
    "LINKED_EXACT",
    "LINKED_NORMALIZED",
    "CREATED",
    "UNCHANGED",
    "SKIPPED_DUPLICATE_LISTING",
    "HELD_FOR_REVIEW",
    "REJECTED_INVALID",
    "CONFLICT_SELLER_SKU",
)

# REVIEWED = human-confirmed via `review resolve --link`
MatchType = Literal["EXACT", "NORMALIZED", "CREATED", "REVIEWED"]
ReviewReason = Literal["FUZZY", "AMBIGUOUS"]
ReviewStatus = Literal["PENDING", "LINKED", "CREATED", "REJECTED"]

WarningCode = Literal[
    "non_uuid_seller_sku",
    "unknown_fields_ignored",
    "blank_brand_treated_as_null",
    "blank_category_treated_as_null",
    "ambiguous_candidates",
    "review_previously_rejected",
]
ViolationCode = Literal[
    "not_an_object",
    "missing",
    "not_a_string",
    "blank",
    "too_long",
    "invalid_charset",
    "unnormalizable",
]
FieldName = Literal["record", "Id", "SellerName", "Name", "Brand", "Category"]


@dataclass(frozen=True)
class FieldViolation:
    field: FieldName
    code: ViolationCode


@dataclass(frozen=True)
class SellerEntry:
    """A record that passed boundary validation."""

    index: int  # 0-based position in the input array
    seller_name: str  # stripped
    seller_product_id: str  # exactly as received (charset already validated)
    name: str  # exactly as received; used for the EXACT comparison and stored as SourceName
    brand: str | None  # as received; blank string becomes None (with a warning)
    category: str | None  # as received; blank string becomes None (with a warning)
    warnings: tuple[WarningCode, ...]


@dataclass(frozen=True)
class RejectedEntry:
    """A record that failed boundary validation; reported, never written."""

    index: int
    seller_name: str | None  # present when that field itself was valid
    seller_product_id: str | None  # present when that field itself was valid
    violations: tuple[FieldViolation, ...]  # all violations, in field order
    warnings: tuple[WarningCode, ...]


@dataclass(frozen=True)
class CatalogProduct:
    id: int
    name: str
    brand: str | None
    category: str | None
    normalized_name: str | None
    normalized_brand: str | None


@dataclass(frozen=True)
class FuzzyCandidate:
    product_id: int
    normalized_name: str


@dataclass(frozen=True)
class MatchQuery:
    raw_name: str
    normalized_name: str  # never None: the use case rejects unnormalizable names first
    normalized_brand: str | None


@dataclass(frozen=True)
class LinkDecision:
    product_id: int
    match_type: Literal["EXACT", "NORMALIZED"]


@dataclass(frozen=True)
class HoldDecision:
    reason: ReviewReason
    candidate_product_id: int | None  # FUZZY: best candidate; AMBIGUOUS: None
    score: float | None  # FUZZY: best ratio; AMBIGUOUS: None
    candidate_product_ids: tuple[int, ...]  # ascending ids


@dataclass(frozen=True)
class CreateDecision:
    best_score: float | None  # best fuzzy ratio below threshold; None when the pool was empty


MatchDecision = LinkDecision | HoldDecision | CreateDecision


@dataclass(frozen=True)
class SellerLink:
    id: int
    seller_name: str
    seller_product_id: str
    product_id: int
    match_type: MatchType


@dataclass(frozen=True)
class NewSellerLink:
    seller_name: str
    seller_product_id: str
    product_id: int
    source_name: str
    source_brand: str | None
    source_category: str | None
    match_type: MatchType


@dataclass(frozen=True)
class NewProduct:
    name: str  # clean_display(entry.name)
    brand: str | None  # clean_display(entry.brand)
    category: str | None  # clean_display(entry.category)
    normalized_name: str
    normalized_brand: str | None


@dataclass(frozen=True)
class ReviewItem:
    id: int
    seller_name: str
    seller_product_id: str
    candidate_product_id: int | None
    score: float | None
    reason: ReviewReason
    status: ReviewStatus


@dataclass(frozen=True)
class NewReviewItem:
    seller_name: str
    seller_product_id: str
    source_name: str
    source_brand: str | None
    source_category: str | None
    candidate_product_id: int | None
    score: float | None
    reason: ReviewReason


@dataclass(frozen=True)
class ProductKeySource:
    product_id: int
    name: str
    brand: str | None


@dataclass(frozen=True)
class EntryOutcome:
    index: int
    seller_name: str | None
    seller_product_id: str | None
    outcome: OutcomeCode
    product_id: int | None
    review_reason: ReviewReason | None
    score: float | None  # unrounded; the report writer rounds
    warnings: tuple[WarningCode, ...]
    errors: tuple[str, ...]  # "<code>:<field>", e.g. "too_long:Name"; empty unless REJECTED_INVALID


@dataclass(frozen=True)
class RunSummary:
    run_id: str  # uuid4().hex, also the log correlationId
    input_label: str  # the --input path as typed
    total: int
    counts: tuple[tuple[OutcomeCode, int], ...]  # every code in OUTCOME_CODES order, zeros included
    rows_written: int
    dry_run: bool
    committed: bool


@dataclass(frozen=True)
class ConsolidationResult:
    outcomes: tuple[EntryOutcome, ...]  # in input order
    summary: RunSummary
