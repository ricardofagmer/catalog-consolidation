from collections.abc import Iterator
from dataclasses import dataclass
from typing import Protocol

from catalog_consolidation.domain.models import (
    CatalogProduct,
    FuzzyCandidate,
    NewProduct,
    NewReviewItem,
    NewSellerLink,
    ProductKeySource,
    RejectedEntry,
    ReviewItem,
    ReviewStatus,
    SellerEntry,
    SellerLink,
)


class CatalogReader(Protocol):
    def find_by_normalized_name(
        self, *, normalized_name: str, normalized_brand: str | None
    ) -> tuple[CatalogProduct, ...]: ...

    def list_brand_compatible(
        self, *, normalized_brand: str | None
    ) -> Iterator[FuzzyCandidate]: ...


class CatalogRepository(CatalogReader, Protocol):
    def find_link_by_sku(
        self, *, seller_name: str, seller_product_id: str
    ) -> SellerLink | None: ...

    def find_link_by_seller_product(
        self, *, seller_name: str, product_id: int
    ) -> SellerLink | None: ...

    def find_review_by_sku(
        self, *, seller_name: str, seller_product_id: str
    ) -> ReviewItem | None: ...

    def insert_product(self, product: NewProduct) -> int: ...

    def insert_link(self, link: NewSellerLink) -> int: ...

    def enqueue_review(self, review: NewReviewItem) -> int: ...

    # Products written by other tools arrive with NULL match keys; the use case heals them
    # at the start of every run so they stay visible to matching (decision recorded 2026-10-05).
    def list_products_missing_match_keys(
        self, *, after_id: int, limit: int
    ) -> tuple[ProductKeySource, ...]: ...

    def set_match_keys(
        self, *, product_id: int, normalized_name: str, normalized_brand: str | None
    ) -> None: ...


class UnitOfWork(Protocol):
    @property
    def catalog(self) -> CatalogRepository: ...

    def commit(self) -> None: ...

    def rollback(self) -> None: ...

    def rows_written(self) -> int: ...  # rows inserted/updated since this unit of work was built


class EntrySource(Protocol):
    def read(self) -> tuple[SellerEntry | RejectedEntry, ...]: ...  # raises InvalidInputFileError


# --- Review queue resolution (T10) -----------------------------------------------------------
# Appended after the frozen contracts; nothing above this line changed.


@dataclass(frozen=True)
class ReviewRecord:
    """A queue row with the seller's original values, as a reviewer needs them."""

    item: ReviewItem
    source_name: str
    source_brand: str | None
    source_category: str | None


class ReviewRepository(Protocol):
    def list_by_status(
        self, *, status: ReviewStatus, after_id: int, limit: int
    ) -> tuple[ReviewRecord, ...]: ...  # keyset on Id, ascending

    def get(self, *, review_id: int) -> ReviewRecord | None: ...

    def product_exists(self, *, product_id: int) -> bool: ...

    # Conditional on the current status, so a concurrent resolution cannot be overwritten.
    def transition_status(
        self, *, review_id: int, from_status: ReviewStatus, to_status: ReviewStatus
    ) -> bool: ...


class ReviewUnitOfWork(Protocol):
    @property
    def catalog(self) -> CatalogRepository: ...

    @property
    def reviews(self) -> ReviewRepository: ...

    def commit(self) -> None: ...

    def rollback(self) -> None: ...
