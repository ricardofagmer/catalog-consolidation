"""Match-key normalization (frozen rule B) and display cleanup (frozen rule C)."""

import re
import unicodedata

# Quotes are deleted, not spaced: `Levi's` must collapse to `levis` to meet `Levis`.
_QUOTE_DELETION_TABLE = str.maketrans("", "", "\"'\u2019\u201c\u201d")
_NON_ALPHANUMERIC_RUN = re.compile(r"[^0-9a-z]+")


def normalize(text: str | None) -> str | None:
    """Return the comparison key for a name or brand, or None when nothing comparable remains.

    The step order is part of the contract, not a style choice:
    NFKD and the combining-mark drop run before casefold so `Câmera` loses its accent and
    meets `camera`; casefold then folds case and expands ligatures such as `ß` to `ss`.
    Quotes are deleted before the non-alphanumeric pass, so `55"` becomes `55` and `Levi's`
    becomes `levis`; replacing them with a space first would split one word into two.
    """
    if text is None:
        return None
    decomposed = unicodedata.normalize("NFKD", text)
    without_marks = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    folded = without_marks.casefold()
    unquoted = folded.translate(_QUOTE_DELETION_TABLE)
    spaced = _NON_ALPHANUMERIC_RUN.sub(" ", unquoted)
    key = " ".join(spaced.split())
    return key or None


def clean_display(text: str | None) -> str | None:
    """Collapse whitespace for the display value of a created product, or None when blank.

    Only whitespace changes: the seller's casing, accents and punctuation are what the
    catalog shows, so they are kept verbatim.
    """
    if text is None:
        return None
    cleaned = " ".join(text.split())
    return cleaned or None
