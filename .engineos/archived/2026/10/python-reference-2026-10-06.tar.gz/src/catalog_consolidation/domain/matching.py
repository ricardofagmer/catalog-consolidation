from difflib import SequenceMatcher

from catalog_consolidation.domain.limits import FUZZY_REVIEW_THRESHOLD
from catalog_consolidation.domain.models import (
    CatalogProduct,
    CreateDecision,
    HoldDecision,
    LinkDecision,
    MatchDecision,
    MatchQuery,
)
from catalog_consolidation.domain.ports import CatalogReader


def match_entry(*, query: MatchQuery, catalog: CatalogReader) -> MatchDecision:
    """Decide link / hold / create for one entry (ADR 0002, frozen rule B)."""
    candidates = catalog.find_by_normalized_name(
        normalized_name=query.normalized_name,
        normalized_brand=query.normalized_brand,
    )
    if len(candidates) == 1:
        return _link_exact_key(query=query, candidate=candidates[0])
    if len(candidates) > 1:
        return HoldDecision(
            reason="AMBIGUOUS",
            candidate_product_id=None,
            score=None,
            candidate_product_ids=tuple(sorted(product.id for product in candidates)),
        )
    return _decide_by_similarity(query=query, catalog=catalog)


def _link_exact_key(*, query: MatchQuery, candidate: CatalogProduct) -> LinkDecision:
    match_type = "EXACT" if candidate.name == query.raw_name else "NORMALIZED"
    return LinkDecision(product_id=candidate.id, match_type=match_type)


def _decide_by_similarity(
    *, query: MatchQuery, catalog: CatalogReader
) -> HoldDecision | CreateDecision:
    # Fuzzy similarity only ever holds for review, never links (frozen rule B).
    matcher = SequenceMatcher(None, query.normalized_name, "", autojunk=False)
    best_id: int | None = None
    best_ratio = 0.0
    for candidate in catalog.list_brand_compatible(normalized_brand=query.normalized_brand):
        matcher.set_seq2(candidate.normalized_name)
        # quick_ratio/real_quick_ratio are upper bounds of ratio, so skipping on a
        # strictly lower bound cannot change the winner (ties still reach the full ratio).
        if best_id is not None and (
            matcher.real_quick_ratio() < best_ratio or matcher.quick_ratio() < best_ratio
        ):
            continue
        ratio = matcher.ratio()
        if _beats_best(
            ratio=ratio,
            product_id=candidate.product_id,
            best_ratio=best_ratio,
            best_id=best_id,
        ):
            best_id = candidate.product_id
            best_ratio = ratio
    if best_id is None:
        return CreateDecision(best_score=None)
    if best_ratio >= FUZZY_REVIEW_THRESHOLD:
        return HoldDecision(
            reason="FUZZY",
            candidate_product_id=best_id,
            score=best_ratio,
            candidate_product_ids=(best_id,),
        )
    return CreateDecision(best_score=best_ratio)


def _beats_best(*, ratio: float, product_id: int, best_ratio: float, best_id: int | None) -> bool:
    # Ties go to the lowest id, independent of the order the reader yields in.
    if best_id is None or ratio > best_ratio:
        return True
    return ratio == best_ratio and product_id < best_id
