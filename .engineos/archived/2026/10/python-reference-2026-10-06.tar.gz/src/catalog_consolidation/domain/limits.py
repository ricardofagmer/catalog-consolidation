from typing import Final

MAX_INPUT_FILE_BYTES: Final = 10 * 1024 * 1024
MAX_INPUT_ENTRIES: Final = 100_000

MAX_SELLER_PRODUCT_ID_LENGTH: Final = 64
MAX_SELLER_NAME_LENGTH: Final = 100
MAX_NAME_LENGTH: Final = 200
MAX_BRAND_LENGTH: Final = 100
MAX_CATEGORY_LENGTH: Final = 100

# Seller SKU is opaque: charset allowlist only, UUID shape is a warning, not a rule.
SELLER_PRODUCT_ID_PATTERN: Final = r"[A-Za-z0-9._-]+"
UUID_PATTERN: Final = r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"

FUZZY_REVIEW_THRESHOLD: Final = 0.80
MAX_EXACT_CANDIDATES: Final = 50
FUZZY_SCAN_BATCH_SIZE: Final = 500
BACKFILL_BATCH_SIZE: Final = 500
REPORT_SCORE_DECIMALS: Final = 4
