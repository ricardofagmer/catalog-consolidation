from typing import Literal

InputFileErrorCode = Literal[
    "unreadable", "too_large", "not_utf8", "not_json", "not_an_array", "too_many_entries"
]
DatabaseFileErrorCode = Literal["not_found", "schema_outdated"]
MigrationErrorCode = Literal["invalid_filename", "version_gap", "checksum_mismatch", "rows_lost"]


class DomainError(Exception):
    """Base of every expected, typed failure."""


class InvalidInputFileError(DomainError):
    def __init__(self, *, code: InputFileErrorCode, detail: str) -> None:
        super().__init__(f"{code}: {detail}")
        self.code: InputFileErrorCode = code
        self.detail = detail


class DatabaseFileError(DomainError):
    def __init__(self, *, code: DatabaseFileErrorCode, detail: str) -> None:
        super().__init__(f"{code}: {detail}")
        self.code: DatabaseFileErrorCode = code
        self.detail = detail


class MigrationError(DomainError):
    def __init__(self, *, code: MigrationErrorCode, detail: str) -> None:
        super().__init__(f"{code}: {detail}")
        self.code: MigrationErrorCode = code
        self.detail = detail
